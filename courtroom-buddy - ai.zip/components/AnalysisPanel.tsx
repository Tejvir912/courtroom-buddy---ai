import React, { useState } from 'react';
import { AnalysisResult, Language } from '../types';
import RiskDial from './RiskDial';
import { AlertTriangle, Gavel, CheckCircle, HelpCircle, FileCheck } from 'lucide-react';

interface AnalysisPanelProps {
  data: AnalysisResult;
  lang: Language;
  onRiskClick: (blockId: string) => void;
}

const AnalysisPanel: React.FC<AnalysisPanelProps> = ({ data, lang, onRiskClick }) => {
  const [activeTab, setActiveTab] = useState<'risks' | 'questions' | 'actions'>('risks');

  const getRiskColor = (level: string) => {
    switch(level) {
        case 'HIGH': return 'bg-red-50 text-red-700 border-red-200';
        case 'MEDIUM': return 'bg-amber-50 text-amber-700 border-amber-200';
        default: return 'bg-emerald-50 text-emerald-700 border-emerald-200';
    }
  };

  return (
    <div className="flex flex-col h-full bg-white rounded-lg shadow-sm border border-slate-200 overflow-hidden">
      {/* Summary Header */}
      <div className="p-6 border-b border-slate-100 bg-slate-50/50">
        <div className="flex items-start justify-between mb-4">
            <div>
                 <h2 className="text-xl font-bold text-slate-900 mb-1">Analysis Report</h2>
                 <p className="text-sm text-slate-500">
                    {lang === 'en' ? 'AI-Generated Legal Insights' : 'एआई-जनित कानूनी अंतर्दृष्टि'}
                 </p>
            </div>
            <div className="bg-white p-2 rounded-lg shadow-sm border border-slate-100">
                 <RiskDial score={data.risk.score} />
            </div>
        </div>
        <div className="bg-blue-50 p-4 rounded-md border border-blue-100">
            <p className="text-sm text-blue-800 leading-relaxed">
                {lang === 'en' ? data.summaries.summary_en : data.summaries.summary_hi}
            </p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-slate-200">
        <button
          onClick={() => setActiveTab('risks')}
          className={`flex-1 py-3 text-sm font-medium flex items-center justify-center gap-2 ${
            activeTab === 'risks' ? 'text-blue-600 border-b-2 border-blue-600 bg-blue-50/30' : 'text-slate-500 hover:text-slate-700'
          }`}
        >
          <AlertTriangle className="w-4 h-4" />
          {lang === 'en' ? 'Risks' : 'जोखिम'}
          <span className="bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded-full text-xs">{data.risk.flags.length}</span>
        </button>
        <button
          onClick={() => setActiveTab('questions')}
          className={`flex-1 py-3 text-sm font-medium flex items-center justify-center gap-2 ${
            activeTab === 'questions' ? 'text-blue-600 border-b-2 border-blue-600 bg-blue-50/30' : 'text-slate-500 hover:text-slate-700'
          }`}
        >
          <HelpCircle className="w-4 h-4" />
          {lang === 'en' ? 'Q&A' : 'प्रश्न'}
        </button>
        <button
          onClick={() => setActiveTab('actions')}
          className={`flex-1 py-3 text-sm font-medium flex items-center justify-center gap-2 ${
            activeTab === 'actions' ? 'text-blue-600 border-b-2 border-blue-600 bg-blue-50/30' : 'text-slate-500 hover:text-slate-700'
          }`}
        >
          <CheckCircle className="w-4 h-4" />
          {lang === 'en' ? 'Action' : 'कार्रवाई'}
        </button>
      </div>

      {/* Tab Content */}
      <div className="flex-1 overflow-y-auto p-4 doc-scroll">
        
        {/* RISKS TAB */}
        {activeTab === 'risks' && (
            <div className="space-y-4">
                {data.risk.flags.map((flag) => (
                    <div 
                        key={flag.risk_id} 
                        onClick={() => onRiskClick(flag.block_id)}
                        className={`p-4 rounded-lg border cursor-pointer hover:shadow-md transition-all ${getRiskColor(flag.level)}`}
                    >
                        <div className="flex items-center justify-between mb-2">
                            <span className="font-bold text-xs px-2 py-0.5 rounded-full bg-white/50 uppercase tracking-wider">{flag.level}</span>
                            <span className="text-xs opacity-75">Page {flag.page}</span>
                        </div>
                        <h4 className="font-semibold mb-1">{flag.type}</h4>
                        <p className="text-sm opacity-90 mb-3">
                            {lang === 'en' ? flag.explanation_en : flag.explanation_hi}
                        </p>
                        <div className="bg-white/40 p-2 rounded text-xs italic border border-black/5">
                            "{flag.excerpt}"
                        </div>
                    </div>
                ))}
            </div>
        )}

        {/* QUESTIONS TAB */}
        {activeTab === 'questions' && (
            <div className="space-y-4">
                {data.questions_for_lawyer.map((q) => (
                    <div key={q.q_id} className="p-4 rounded-lg border border-slate-200 bg-slate-50">
                        <div className="flex items-center gap-2 mb-2">
                            <div className={`w-2 h-2 rounded-full ${q.priority === 'High' ? 'bg-red-500' : 'bg-blue-500'}`}></div>
                            <span className="text-xs font-semibold text-slate-500 uppercase">Ask Lawyer • {q.priority} Priority</span>
                        </div>
                        <p className="font-medium text-slate-800 mb-2">
                            {lang === 'en' ? q.question_en : q.question_hi}
                        </p>
                        <span className="text-xs text-slate-400 bg-white px-2 py-1 rounded border border-slate-200">
                            Ref: {q.ref}
                        </span>
                    </div>
                ))}
            </div>
        )}

        {/* ACTIONS TAB */}
        {activeTab === 'actions' && (
            <div className="space-y-0">
                {data.action_plan.map((step, idx) => (
                    <div key={idx} className="flex gap-4 pb-6 last:pb-0 relative group">
                        {/* Connecting Line */}
                        {idx !== data.action_plan.length - 1 && (
                            <div className="absolute left-[15px] top-8 bottom-0 w-0.5 bg-slate-200 group-hover:bg-blue-200 transition-colors"></div>
                        )}
                        
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 z-10 ${step.urgency === 'Immediate' ? 'bg-amber-100 text-amber-700 ring-4 ring-white' : 'bg-blue-100 text-blue-700 ring-4 ring-white'}`}>
                            {idx + 1}
                        </div>
                        <div className="pt-1">
                            <div className="flex items-center gap-2 mb-1">
                                <span className={`text-[10px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded ${step.urgency === 'Immediate' ? 'bg-red-100 text-red-600' : 'bg-slate-100 text-slate-500'}`}>
                                    {step.urgency}
                                </span>
                            </div>
                            <p className="text-sm text-slate-700">
                                {lang === 'en' ? step.description_en : step.description_hi}
                            </p>
                        </div>
                    </div>
                ))}
            </div>
        )}

      </div>
    </div>
  );
};

export default AnalysisPanel;