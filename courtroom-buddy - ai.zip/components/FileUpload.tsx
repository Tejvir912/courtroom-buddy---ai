import React, { useCallback, useState } from 'react';
import { UploadCloud, FileType, Check, AlertCircle } from 'lucide-react';

interface FileUploadProps {
  onFileSelect: (file: File) => void;
}

const FileUpload: React.FC<FileUploadProps> = ({ onFileSelect }) => {
  const [isDragging, setIsDragging] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleDrag = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setIsDragging(true);
    } else if (e.type === 'dragleave') {
      setIsDragging(false);
    }
  }, []);

  const validateAndUpload = (file: File) => {
    // Validation for PDF, Images, DOC, DOCX
    const validTypes = [
      'application/pdf',
      'application/msword', // .doc
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document' // .docx
    ];

    if (!validTypes.includes(file.type) && !file.type.includes('image')) {
        setError("Supported formats: PDF, DOC, DOCX, JPG, PNG");
        return;
    }
    setError(null);
    onFileSelect(file);
  };

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      validateAndUpload(e.dataTransfer.files[0]);
    }
  }, []);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    if (e.target.files && e.target.files[0]) {
      validateAndUpload(e.target.files[0]);
    }
  };

  return (
    <div className="w-full max-w-xl mx-auto">
        <div
        className={`
            relative flex flex-col items-center justify-center w-full h-64 rounded-xl border-2 border-dashed transition-all duration-300
            ${isDragging ? 'border-blue-500 bg-blue-50' : 'border-slate-300 bg-white hover:bg-slate-50'}
            ${error ? 'border-red-300 bg-red-50' : ''}
        `}
        onDragEnter={handleDrag}
        onDragLeave={handleDrag}
        onDragOver={handleDrag}
        onDrop={handleDrop}
        >
        <div className="flex flex-col items-center justify-center pt-5 pb-6 text-center px-4">
            <div className={`p-4 rounded-full mb-4 ${isDragging ? 'bg-blue-100 text-blue-600' : 'bg-slate-100 text-slate-500'}`}>
                <UploadCloud className="w-8 h-8" />
            </div>
            <p className="mb-2 text-lg font-medium text-slate-700">
            <span className="font-semibold text-blue-600">Click to upload</span> or drag and drop
            </p>
            <p className="text-sm text-slate-500">PDF, DOC, DOCX, JPG, PNG (Max 10MB)</p>
        </div>
        <input
            id="dropzone-file"
            type="file"
            className="absolute w-full h-full opacity-0 cursor-pointer"
            onChange={handleChange}
            accept=".pdf,.doc,.docx,image/*"
        />
        </div>
        
        {error && (
            <div className="mt-4 flex items-center gap-2 text-red-600 text-sm bg-red-50 p-3 rounded-md border border-red-200">
                <AlertCircle className="w-4 h-4" />
                {error}
            </div>
        )}

        <div className="mt-8">
            <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">Sample Documents</p>
            <div className="flex gap-3">
                {['Rental_Agreement.pdf', 'Employment_Offer.docx'].map((doc) => (
                    <button key={doc} className="flex items-center gap-2 px-3 py-2 bg-white border border-slate-200 rounded text-sm text-slate-600 hover:border-blue-300 hover:text-blue-600 transition-colors">
                        <FileType className="w-4 h-4" />
                        {doc}
                    </button>
                ))}
            </div>
        </div>
    </div>
  );
};

export default FileUpload;