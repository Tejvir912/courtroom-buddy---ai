import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';

interface RiskDialProps {
  score: number; // 0 to 100
}

const RiskDial: React.FC<RiskDialProps> = ({ score }) => {
  // Score 0-100. 100 is High Risk.
  
  const data = [
    { name: 'Score', value: score },
    { name: 'Remaining', value: 100 - score },
  ];

  let color = '#10b981'; // Green (Low risk)
  if (score > 40) color = '#f59e0b'; // Orange (Medium)
  if (score > 70) color = '#ef4444'; // Red (High)

  return (
    <div className="flex flex-col items-center justify-center relative">
      <div className="w-48 h-24 overflow-hidden relative">
        <ResponsiveContainer width="100%" height="200%">
          <PieChart>
            <Pie
              data={data}
              cx="50%"
              cy="50%"
              startAngle={180}
              endAngle={0}
              innerRadius={60}
              outerRadius={80}
              paddingAngle={0}
              dataKey="value"
            >
              <Cell key="score" fill={color} />
              <Cell key="bg" fill="#e2e8f0" />
            </Pie>
          </PieChart>
        </ResponsiveContainer>
        <div className="absolute bottom-0 left-0 right-0 flex flex-col items-center justify-end">
             <span className="text-3xl font-bold text-slate-800">{score}/100</span>
        </div>
      </div>
      <span className="text-sm font-medium text-slate-500 mt-2 uppercase tracking-wide">Risk Score</span>
    </div>
  );
};

export default RiskDial;