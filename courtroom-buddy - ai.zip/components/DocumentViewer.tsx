import React from 'react';
import { Page, Block } from '../types';
import { FileText } from 'lucide-react';

interface DocumentViewerProps {
  pages: Page[];
  highlightBlockId?: string | null;
}

const DocumentViewer: React.FC<DocumentViewerProps> = ({ pages, highlightBlockId }) => {
  return (
    <div className="bg-slate-100 border border-slate-200 rounded-lg h-full flex flex-col">
        <div className="bg-white p-3 border-b border-slate-200 flex items-center justify-between">
            <h3 className="text-sm font-semibold text-slate-700 flex items-center gap-2">
                <FileText className="w-4 h-4" />
                Original Document
            </h3>
            <span className="text-xs text-slate-400">Viewing Page 1 of {pages.length}</span>
        </div>
      <div className="flex-1 overflow-y-auto p-8 doc-scroll bg-slate-50">
        <div className="max-w-3xl mx-auto bg-white shadow-lg min-h-[800px] p-12 border border-slate-200">
          {pages.map((page) => (
            <div key={page.page_number} className="mb-8">
              {page.blocks.map((block) => (
                <div
                  key={block.block_id}
                  id={`block-${block.block_id}`}
                  className={`
                    mb-3 transition-colors duration-300 rounded px-1
                    ${block.type === 'heading' ? 'text-center font-bold text-lg mb-6 uppercase' : ''}
                    ${block.type === 'clause' ? 'text-justify font-serif text-slate-800 leading-relaxed' : ''}
                    ${block.type === 'paragraph' ? 'text-slate-600 mb-4' : ''}
                    ${highlightBlockId === block.block_id ? 'bg-amber-100 ring-2 ring-amber-400' : 'hover:bg-slate-50'}
                  `}
                >
                  {block.text}
                </div>
              ))}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default DocumentViewer;